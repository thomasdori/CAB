vti_encoding:SR|utf8-nl
vti_author:SR|EKI-CONSULTING\\CCALDERON
vti_modifiedby:SR|EKI-CONSULTING\\CCALDERON
vti_timecreated:TR|15 Oct 2003 19:28:39 -0000
vti_timelastmodified:TR|15 Oct 2003 19:28:39 -0000
vti_cacheddtm:TX|15 Oct 2003 19:28:39 -0000
vti_filesize:IR|6216
vti_extenderversion:SR|4.0.2.6513
vti_backlinkinfo:VX|
