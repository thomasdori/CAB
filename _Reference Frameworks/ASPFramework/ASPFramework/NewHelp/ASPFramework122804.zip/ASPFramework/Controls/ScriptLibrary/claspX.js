claspCore = function() {
	this.name		= "CLASP";
	this.version	= "1.8";
	this.scriptPath = SCRIPT_LIBRARY_PATH;
	this.events      = new this.notloaded;	
	this.dhtml       = new this.notloaded;
	this.form		 = new claspForm
	this.form.validation = new this.notloaded;
	this.ie    = (document.all)	   ? true : false;
	this.bwok  = (this.ie);
	this.ns4   = (document.layers) ? true : false;

	this.windowname  = window.name;
	
	
};//end clasp core

claspCore.prototype.events      = null;
claspCore.prototype.dhtml       = null;

claspCore.prototype.notloaded = function(	) {
		this.loaded  = false;
		this.version = "1.0";
	}	
	
claspCore.prototype.loadLibrary = function(name) {
	var load = false;
	var libsrc;	
	switch(name) {
		case "dhtml":
			if(!this.dhtml.loaded) {
				load=true;
				libsrc = "dhtml.js";
			}			
			break;
		case "events":
			if(!this.events.loaded) {
				load=true;
				libsrc = "events.js";				
			}
			break;
		case "validation":
			if(!this.form.validation.loaded) {
				load=true;
				libsrc = "validation.js";				
			}
			break;					
	}
	if(load)		
		document.write('<script language="Javascript1.2" src="'+ this.scriptPath + libsrc + '"><\/script>');
}

claspCore.prototype.launchApplication = function(name,width,height) {

	if(window.name == name)	return;
	if(window.opener) if(window.opener.name == name) return;
	
	if(!height) height = screen.height - 100;
	if(!width)  width  = screen.width  - 100;
	var left = (screen.width / 2 ) - width / 2;

	window.name = name + "_close";	
	window.open(location.href + location.search,name,"scrollbars,width=" + width + ",height=" + height + ",top=10,left=" + left)
	clasp.closeAppWindow();					
}

claspCore.prototype.closeAppWindow = function() {
	if(window.history.length == 0){
		self.opener = self;
		self.close()
		return;		
	}	
	if(window.history.length > 0)
		window.history.back();
}

claspCore.prototype.openWindow = function(name,url,left,top,width,height,scrollable,resizable,extraAttributes) {
	var params = "";
	if(left == -1) left =  ((screen.width - width)/2);  
	if(top  == -1)  top =  ((screen.height - height)/2);
	if(scrollable == null) scrollable = false;
	if(resizable  == null) resizable  = false;
	if(extraAttributes=="") extraAttributes = "status=yes,dependent=yes,alwaysRaised=yes"
	params = "left=" + left  + ", " + "top=" + top + ","	
	params = params + "width=" + width + "," + "height=" +  height + "," 
	params = params + "scrollbars=" + (scrollable?"yes":"no") + ","
	params = params + "resizable=" + (resizable?"yes":"no");
	params = params + (extraAttributes?("," + extraAttributes):"")
	return window.open(url,name,params);
}

claspCore.prototype.getObject = function (n, d) {
  var p,i,x;  

  if(!d) d=document; 
  	if((p=n.indexOf("?"))>0&&parent.frames.length) {  		
		d=parent.frames[n.substring(p+1)].document; 
		n=n.substring(0,p);		
	}
	if(!(x=d[n])&&d.all) {
		x=d.all[n]; 
		
	}
	for (i=0;!x&&i<d.forms.length;i++) {
		x=d.forms[i][n];		
	}
	for(i=0;!x&&d.layers&&i<d.layers.length;i++) {
		x=clasp.getObject(n,d.layers[i].document); 
		
	}	
	for(i=0;!x&&d.layers&&i<document.links.length;i++)		
		if(document.links[i].href.indexOf("'" + n + "'")>0) {
			x = document.links[i];
			break;
		}	
	//alert(n + ":" + x)	
	if(!x) { //alert(n)
		if(clasp.events.objcache)
			x = eval("clasp.events.objcache." + n);
	}
						
	return x;
}

claspCore.prototype.openInFrame = function(fn,url){
	var myname;
	var fr = this.getFrame(fn);
	if (url && fr) fr.location = url;
	else {
		// load me inside the correct frame
		url = self.location;
		myname = self.name;
		if (fr && fn!=myname){
			fr.location = url;
			self.location = "about:blank";
		}
	}
};

claspCore.prototype.getFrame = 	function (fn){
	var f=document.frames[fn];
	if (!f) f= parent.frames[fn];
	if (!f) f= window.frames[fn];
	if (!f && window.frames['top']) f= window.frames['top'].frames[fn];
	return f;
};

claspForm = function() {
			this.loaded=true;			
			this.version = "1.0";
			this.name  = "CLASPForm"; //this is the name I want to use...
			this.name2 = "frmForm";   //support current versions
			this.validator = null;
}

claspForm.prototype.doPostBack = doPostBack;

claspForm.prototype.resetScroll = function(noRetry) {	
	if(!document.layers)  {		
	  var frm = clasp.form.getForm()
	  document.body.scrollTop  = frm.__SCROLLTOP.value;
	  document.body.scrollLeft = frm.__SCROLLLEFT.value;
	}
	
	// retry 10ms after page if scroll didn't reset
	if (!noRetry && (document.body.scrollTop!=frm.__SCROLLTOP.value)) {
		window.setTimeout('clasp.form.resetScroll(true)',10);
	}
}

claspForm.prototype.getForm = function() {	
	if(!this.form) {
		this.form = eval("document." + this.name);
		if(!this.form)
			this.form = eval("document." + this.name2);
	}
	return this.form;
}

claspForm.prototype.getField = function(fieldName) {
	var frm = this.getForm();
	var fld = eval("frm." + fieldName);
	return fld;
}

claspForm.prototype.enableField = function(fieldName) {
	var fld = this.getField(fieldName);
	fld.disabled = false;
}

claspForm.prototype.disableField = function(fieldName) {
	var fld = this.getField(fieldName);
	fld.disabled = true;
}

claspForm.prototype.isEnabled = function(fieldName) {
	var fld = this.getField(fieldName);	
	if(fld.disabled == null)
		return true;
	else
		return !fld.disabled;
}

claspForm.prototype.isDate = function(fieldName) {
	var fld  = this.getField(fieldName);
	var tst  = new Date(fld.value||'');
	return(!isNaN(tst));	
}

claspForm.prototype.isNumeric = function(fieldName) {
	var fld  = this.getField(fieldName);
	var tst  = new Number(fld.value||'');
	return(!isNaN(tst));
}


claspForm.prototype.hasValue = function(fieldName,def) {
	var fld = this.getField(fieldName);
	if(fld) {
		switch(fld.type) {
			case "text":			return (fld.value!="" && fld.value!=def);
			case "textarea":		return (fld.value!="" && fld.value!=def);
			case "password":		return (fld.value!="" && fld.value!=def);
			case "checkbox":		return fld.checked;
			case "select-one":		return (fld.value!="" && fld.value!=def)
			case "select-multiple":	return fld.selectedIndex>0;
			case "radio":			return fld.checked;
			default:				for(var i=0;i<fld.length;i++) if(fld[i].checked)return true; return false;
		}			
	}
	return false;
}

claspForm.prototype.isFieldPresent= function(fieldName) {
	var fld = this.getField(fieldName);
	return fld!=null;
}

claspForm.prototype.isClaspField= function(fieldName) {	
	return ( fieldName == "__FVERSION" || fieldName == "__ACTION"   || fieldName == "__SOURCE" ||
			 fieldName == "__INSTANCE" || fieldName == "__EXTRAMSG" || fieldName == "__ISPOSTBACK" ||
			 fieldName == "__ISREDIRECTEDPOSTBACK" || fieldName == "__SCROLLTOP" ||  fieldName == "__SCROLLLEFT" ||
			 fieldName == "__VIEWSTATE" || fieldName == "__VIEWSTATECOMPRESSED" )
}

claspForm.prototype.disableFieldsIn = function(containerID) {
	var container = document.all[containerID];
	if(container) {
		if(container)container.disabled = true;
		for(var x=0;x<container.all.length;x++)
			if(container.all[x].type) 
				container.all[x].disabled = true;		
	}
}
claspForm.prototype.enableFieldsIn = function(containerID) {
	var container = document.all[containerID];
	if(container) {
		if(container)container.disabled = false;
		for(var x=0;x<container.all.length;x++)
			if(container.all[x].type) 
				container.all[x].disabled = false;		
	}
}

clasp = new claspCore()
clasp.ua = new BrowserCheck();
clasp.loadLibrary("events");

//BACKWARD FUNCTIONALITY
	function doSubmit() {		
		alert('should not execute!');
		return false
	}	

	function doPostBack(action,object,instance,xmsg,frmaction,frameName) {
				
		var frm = document.frmForm;
		if(frm.__onSubmit) 
			if(!frm.__onSubmit()) return;								
			
		if(clasp.form.validator) {			
			var o = clasp.getObject(object);
			if(o) 
				if(!o.skipvalidation) 
				   if(!clasp.form.validator(o.validationgroup)) 
					  return;			
		}
		
		if(typeof(instance)=='object') {				
				if(instance.type == 'select-one' || instance.type == 'select-multiple')
					frm.__INSTANCE.value   = instance.selectedIndex;	
		}
		else {
			frm.__INSTANCE.value   = instance?instance:'0';	
		}
	
		frm.__ISPOSTBACK.value = "True";
		frm.__ACTION.value     = action;
		frm.__SOURCE.value     = object;
		frm.__EXTRAMSG.value   = xmsg;
		
		//To Restore Scroll Position
		if(!document.layers) {
			frm.__SCROLLTOP.value  = document.body.scrollTop;
			frm.__SCROLLLEFT.value = document.body.scrollLeft;
		}
		else {
			frm.__SCROLLTOP.value  = 0;
			frm.__SCROLLLEFT.value = 0;				
		}
		
		//Netscape 4.7 hmmm
		if(document.layers && !frmaction) {
			frm.action  = window.location;		
		}
		
		if(frmaction) { 
			frm.action = frmaction;
			frm.__ISREDIRECTEDPOSTBACK.value = 1
		}
		
		//Opens in another frame?
		if(frameName)
			frm.target = frameName;
		frm.submit();	
		return;
	}
	
// Webcontrol - A simple object which is used to invoke events on the server 
WebControl = function(name) {
	this.ctrlName = name;
	this.id = "WebControl"+(WebControl._idcnt++);
	WebControl.all[this.id] = this;
};
WebControl.all = [];
WebControl._idcnt = 0
WebControl.prototype.invokeEvent = function(action,instance,xmsg,frmaction,frameName) {
	clasp.form.doPostBack(action,this.ctrlName,instance,xmsg,frmaction,frameName);
};
WebControl.prototype.toString = function(){
	return "WebControl.all." + this.id;
};	
//
// BrowserCheck
function BrowserCheck() {
	this.ns4 = (document.layers)? true:false;
	this.ie = (document.all&&(!window.opera))? true:false;
	this.dom = (document.getElementById)? true:false;
	this.ns6 = (window.sidebar)? true:false;
	this.moz = (window.sidebar||navigator.userAgent.indexOf('Gecko')!=-1)? true:false;
	this.opera = (window.opera)? true:false;
	this.mac = (navigator.userAgent.indexOf('Mac')!=-1)? true:false;
}
	
// Webcontrol - A simple object which is used to invoke events on the server 
WebControl = function(name) {
	this.ctrlName = name;
	this.id = "WebControl"+(WebControl._idcnt++);
	WebControl.all[this.id] = this;
};
WebControl.all = [];
WebControl._idcnt = 0
WebControl.prototype.invokeEvent = function(action,instance,xmsg,frmaction,frameName) {
	clasp.form.doPostBack(action,this.ctrlName,instance,xmsg,frmaction,frameName);
};
WebControl.prototype.toString = function(){
	return "WebControl.all." + this.id;
};	
//
